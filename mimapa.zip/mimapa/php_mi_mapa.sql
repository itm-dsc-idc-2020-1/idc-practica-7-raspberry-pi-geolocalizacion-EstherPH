--
-- php_mi_mapa.sql
--
-- Crear un mapa con coordenadas almacenadas en MySQL
-- Rogelio Ferreira Escutia - mayo 2017

create database php_mi_mapa;
use php_mi_mapa;
create table lugares (nombre text, id int, numero int, latitud text, longitud text);

-- Coordenadas del Edificio "I" del Departamento de Sistemas y Computación del ITM

insert into lugares values("Edificio I", 1, 1, "19.722418", "-101.185591");
insert into lugares values("Edificio I", 1, 1, "19.722366", "-101.185204");
insert into lugares values("Edificio I", 1, 1, "19.722087", "-101.185252");
insert into lugares values("Edificio I", 1, 1, "19.722143", "-101.185633");