function dibujar(latitud1, longitud1, latitud2, longitud2,latitud3,longitud3,latitud4,longitud4){

 
    /*latitud3 = 19.721831;
    longitud3  = -101.186106;
    latitud4 =19.721784;
    longitud4  = -101.185764;*/
    var canvas=document.getElementById('mapa');
	if(canvas&&canvas.getContext){
		var ctx=canvas.getContext("2d");
		if (ctx) {
            
            //Conversion de datos que se reciben
            a=parseFloat(latitud1);
            b=parseFloat(longitud1);
            c=parseFloat(latitud2);
            d=parseFloat(longitud2);

            e=parseFloat(latitud3);
            f=parseFloat(longitud3);
            g=parseFloat(latitud4);
            h=parseFloat(longitud4);
            
            document.write("<br />Recibiendo: "+a+" "+b+" "+c+" "+d+" ");
            
            // Regla de 3 para calcular el primer punto
  
            latitud_superior =  19.722418;
            y1 = ((latitud_superior - a)*500)/0.01108;
            longitud_superior = -101.186516;
            x1 = ((longitud_superior - b)*1000)/(-0.001597);
            document.write("<br />x1: "+x1+" y1: "+y1);
            
            // Dibujar un círculo en el primer punto
            ctx.beginPath();
            ctx.arc(x1,y1,5, 0, 2*Math.PI,true);
            ctx.stroke();
            
            // Regla de 3 para calcular el segundo punto
            y2 = ((latitud_superior - c)*500)/0.01108;
            x2 = ((longitud_superior - d)*1000)/(-0.001597);
            document.write("<br />x2: "+x2+" y2: "+y2);
            
            // Dibujar un círculo en el segundo punto
            ctx.beginPath();
            ctx.arc(x2,y2,5, 0, 2*Math.PI,true);
            ctx.stroke();

            //19.721833, -101.185834 GPS

            

           //19.725437, -101.187128
            latitud_inferior = 19.725437;
            longitud_inferior = -101.186516;



            y3 = ((e - latitud_inferior)*(500))/(0.01108);
            x3 = (( f  - longitud_inferior)*(1000))/(-0.001597);

            y4 = ((g - latitud_inferior)*(500))/(0.01108);
            x4 = (( h - longitud_inferior)*(1000))/(-0.001597);


            document.write("<br />x3: "+x3+" y3: "+y3);
            ctx.beginPath();
            ctx.arc(Math.abs(x3),Math.abs(y3),5, 0, 2*Math.PI,true);
            ctx.stroke();

            document.write("<br />x4: "+x4+" y4: "+y4);
            ctx.beginPath();
            ctx.arc(Math.abs(x4),Math.abs(y4),5, 0, 2*Math.PI,true);
            ctx.stroke();

            //GPS

            //19.721841, -101.185835
            //19.721865, -101.185808
            g1 = 19.721865;
            g2 = -101.185808;
            //
            //
            //19.722076, -101.186003
            gy = (( 19.722895 - g1)*(500))/(0.01108);
            gx = (( longitud_superior - g2)*(1000))/(-0.001597);
            ctx.beginPath();
            ctx.arc(Math.abs(gx),Math.abs(gy),5, 0, 2*Math.PI,true);
            ctx.stroke();
            document.write("<br />gpsx: "+gx+" gpsy: "+gy);

            // Dibujar linea
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();

            // Dibujar linea
            ctx.beginPath();
            ctx.moveTo(x2, y2);
            ctx.lineTo(Math.abs(x4), Math.abs(y4));
            ctx.stroke();

            // Dibujar linea
            ctx.beginPath();
            ctx.moveTo(Math.abs(x4), Math.abs(y4) );
            ctx.lineTo(Math.abs(x3), Math.abs(y3));
            ctx.stroke();

             // Dibujar linea
             ctx.beginPath();
             ctx.moveTo(Math.abs(x3), Math.abs(y3) );
             ctx.lineTo(Math.abs(x1), Math.abs(y1));
             ctx.stroke();
            
		} else { alert("Error al crear el contexto"); }
	}   
}