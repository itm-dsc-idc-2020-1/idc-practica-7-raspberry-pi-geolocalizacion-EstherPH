<!DOCTYPE html>

<!--

index.html

Lee coordenadas de MySQL y dibuja en pantalla
el mapa del Edificio "I" del ITM
Rogelio Ferreira Escutia - Mayo 2017

-->

<html lang="es">
	<head>
        <meta charset="utf-8" />
		<title>PHP Mi Mapa</title>
        <link rel="icon" type="image/png" href="favicon.ico" />
        <link rel="stylesheet" type="text/css" href="php_mi_mapa.css" />
        <script language="javascript" src="php_mi_mapa.js"></script>
	</head>
	<body>
		<h1>PHP Mi Mapa</h1>
        <canvas id="mapa" width="1000px" height="500px">
			Tu navegador no soporta CANVAS
		</canvas>
        <?PHP
            $servidor="localhost";
            $usuario="root";
			$clave="";
            $conexion = mysqli_connect($servidor, $usuario, $clave,"php_mi_mapa");
            if (mysqli_connect_errno())
            {
                echo "Error al conectarse a MySQL: " . mysqli_connect_error();
            }
            $sql = "select * from lugares";
            $resultado=mysqli_query($conexion, $sql);
            $renglon=mysqli_fetch_array($resultado,MYSQLI_ASSOC);
            $latitud1 = $renglon['latitud'];
            $longitud1 = $renglon['longitud'];
            echo "<br />Latitud 1: ".$latitud1. " Longitud 1: ".$longitud1;
            $renglon=mysqli_fetch_array($resultado,MYSQLI_ASSOC);
            $latitud2 = $renglon['latitud'];
            $longitud2 = $renglon['longitud'];
            echo "<br />Latitud 2: ".$latitud2. " Longitud 2: ".$longitud2;  
            $renglon=mysqli_fetch_array($resultado,MYSQLI_ASSOC);
            $latitud3 = $renglon['latitud'];
            $longitud3 = $renglon['longitud'];
            echo "<br />Latitud 3: ".$latitud3. " Longitud 3: ".$longitud3;    
            $renglon=mysqli_fetch_array($resultado,MYSQLI_ASSOC);
            $latitud4 = $renglon['latitud'];
            $longitud4 = $renglon['longitud'];
            echo "<br />Latitud 4: ".$latitud4. " Longitud 4: ".$longitud4;  
            echo "<script>dibujar($latitud1, $longitud1, $latitud2, $longitud2, $latitud3,$longitud3,$latitud4,$longitud4);</script>";
            mysqli_close($conexion);
		?>
	</body>
</html>
